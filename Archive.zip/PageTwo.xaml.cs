namespace AvaTerminal3;

public partial class PageTwo : ContentPage
{
    public PageTwo()
    {
        InitializeComponent();
    }
}
