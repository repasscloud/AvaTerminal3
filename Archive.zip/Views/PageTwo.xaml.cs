namespace AvaTerminal3.Views;

public partial class PageTwo : ContentPage
{
    public PageTwo()
    {
        InitializeComponent();
    }
}
