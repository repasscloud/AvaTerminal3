namespace AvaTerminal3;

public partial class PageOne : ContentPage
{
    public PageOne()
    {
        InitializeComponent();
    }
}
