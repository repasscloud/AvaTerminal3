namespace AvaTerminal3.Views;

public partial class PageOne : ContentPage
{
    public PageOne()
    {
        InitializeComponent();
    }
}
